// Importar Firebase
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-app.js";
import {
  getFirestore
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";

// Configuración de Firebase
const firebaseConfig = {
  apiKey: "AIzaSyCrrJVf8kkjMPoQsLL4bCjSzyjl8-USwXY",
  authDomain: "rifa-pro-cirugia-23210.firebaseapp.com",
  projectId: "rifa-pro-cirugia-23210",
  storageBucket: "rifa-pro-cirugia-23210.firebasestorage.app",
  messagingSenderId: "673501146355",
  appId: "1:673501146355:web:0c9ab4c4dd39a6628bdb86",
  measurementId: "G-V99ENBS23D"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);

// Inicializar Firestore
const db = getFirestore(app);

// Exportar la base de datos
export { db };